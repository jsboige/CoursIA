import pathlib
import sys
import unittest

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "src"))

from bloodlog.baseline import baseline_plan, threshold_plan
from bloodlog.data import make_instance
from bloodlog.milp import solve_milp
from bloodlog.rolling import solve_rolling
from bloodlog.verifier import evaluate

try:
    import pulp  # noqa: F401
    HAS_PULP = True
except ImportError:
    HAS_PULP = False


class TestPolicies(unittest.TestCase):
    def test_threshold_baseline_is_feasible_and_never_substitutes(self):
        inst = make_instance(seed=1, T=21, L=7)
        res = evaluate(inst, threshold_plan(inst))
        self.assertTrue(res["ok"], res["violations"])
        self.assertEqual(res["substitutions"], 0)

    def test_rolling_policy_is_feasible_and_uses_budget(self):
        inst = make_instance(seed=2, T=14, L=7, variability=0.4)
        plan = solve_rolling(inst, replan_every=7, time_limit=10)
        res = evaluate(inst, plan)
        self.assertTrue(res["ok"], res["violations"])
        self.assertLessEqual(res["collectes"], inst.N)

    def test_oracle_is_a_lower_bound_for_all_policies(self):
        inst = make_instance(seed=3, T=14, L=7, variability=0.4)
        oracle = solve_milp(inst, time_limit=60, mip_gap=0.0)
        best = evaluate(inst, oracle["plan"])["objective"]
        for plan in (baseline_plan(inst), threshold_plan(inst), solve_rolling(inst, replan_every=7, time_limit=10)):
            self.assertLessEqual(best, evaluate(inst, plan)["objective"] + 1e-6)

    def test_reproducible_instances(self):
        a, b = make_instance(seed=5), make_instance(seed=5)
        self.assertEqual(a.demand, b.demand)
        self.assertEqual(a.init_stock, b.init_stock)
        self.assertNotEqual(make_instance(seed=6).demand, a.demand)


@unittest.skipUnless(HAS_PULP, "pulp non installe : pip install pulp")
class TestPulpBackend(unittest.TestCase):
    def test_pulp_and_scipy_reach_the_same_optimum(self):
        from bloodlog.milp_pulp import solve_milp_pulp
        inst = make_instance(seed=2, T=14, L=7, variability=0.4)
        a = solve_milp(inst, time_limit=60, mip_gap=0.0)
        b = solve_milp_pulp(inst, time_limit=60, mip_gap=0.0)
        self.assertIsNotNone(b["plan"])
        self.assertTrue(evaluate(inst, b["plan"])["ok"])
        self.assertAlmostEqual(a["objective"], b["objective"], places=3)


if __name__ == "__main__":
    unittest.main()
