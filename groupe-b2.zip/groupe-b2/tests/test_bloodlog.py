import pathlib
import sys
import unittest

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "src"))

from bloodlog.baseline import baseline_plan
from bloodlog.data import DONORS, GROUPS, RECIPIENTS, compatible, make_instance
from bloodlog.milp import solve_milp
from bloodlog.verifier import evaluate


class TestCompatibility(unittest.TestCase):
    def test_universal_donor_and_recipient(self):
        self.assertEqual(sorted(RECIPIENTS["O-"]), sorted(GROUPS))
        self.assertEqual(sorted(DONORS["AB+"]), sorted(GROUPS))

    def test_known_cases(self):
        self.assertFalse(compatible("A+", "O+"))
        self.assertFalse(compatible("O+", "O-"))
        self.assertEqual(sorted(RECIPIENTS["AB-"]), ["AB+", "AB-"])
        self.assertEqual(sorted(RECIPIENTS["A+"]), ["A+", "AB+"])

    def test_pair_count(self):
        self.assertEqual(sum(len(v) for v in RECIPIENTS.values()), 27)


class TestVerifier(unittest.TestCase):
    def setUp(self):
        self.inst = make_instance(seed=0, T=7, L=5)

    def test_baseline_is_feasible(self):
        res = evaluate(self.inst, baseline_plan(self.inst))
        self.assertTrue(res["ok"], res["violations"])

    def test_detects_incompatibility(self):
        plan = {"collect": {}, "issue": {("A+", "O+", 0, 0): 1}}
        res = evaluate(self.inst, plan)
        self.assertFalse(res["ok"])
        self.assertTrue(any("incompatibilite" in v for v in res["violations"]))

    def test_detects_missing_stock(self):
        plan = {"collect": {}, "issue": {("AB-", "AB-", 0, 0): 10_000}}
        res = evaluate(self.inst, plan)
        self.assertTrue(any("stock insuffisant" in v for v in res["violations"]))

    def test_detects_too_many_collection_days(self):
        collect = {(g, t): 1 for t in range(self.inst.T) for g in ["O+"]}
        res = evaluate(self.inst, {"collect": collect, "issue": {}})
        self.assertTrue(any("jours de collecte" in v for v in res["violations"]))

    def test_unserved_demand_is_counted_as_shortage(self):
        res = evaluate(self.inst, {"collect": {}, "issue": {}})
        self.assertEqual(res["shortage"], sum(self.inst.demand.values()))


class TestMilp(unittest.TestCase):
    def test_milp_plan_is_valid_and_not_worse_than_baseline(self):
        inst = make_instance(seed=2, T=14, L=7, variability=0.4, cover=1.05)
        r = solve_milp(inst, time_limit=60, mip_gap=0.0)
        self.assertIsNotNone(r["plan"])
        m = evaluate(inst, r["plan"])
        b = evaluate(inst, baseline_plan(inst))
        self.assertTrue(m["ok"], m["violations"])
        self.assertAlmostEqual(r["objective"], m["objective"], places=4)  # solveur == verificateur
        self.assertLessEqual(m["objective"], b["objective"] + 1e-6)

    def test_infeasible_collection_budget_creates_shortage_not_crash(self):
        inst = make_instance(seed=3, T=10, L=5)
        inst.N = 0                                   # aucune collecte autorisee
        r = solve_milp(inst, time_limit=30)
        m = evaluate(inst, r["plan"])
        self.assertTrue(m["ok"], m["violations"])
        self.assertGreater(m["shortage"], 0)


if __name__ == "__main__":
    unittest.main()
