"""Experiences completes : 4 methodes x 2 durees de vie x variabilites x graines.

Methodes : baseline_fifo (calendrier fixe), baseline_seuil (point de commande),
           milp_replanifie (sans oracle), milp_oracle (demande connue = borne).
Ecrit results/results.csv et results/sensibilite_poids.csv (ajout ligne a ligne).

Usage : python run_experiments.py                # configuration finale (~30 min, 1 coeur)
        python run_experiments.py --quick        # verification rapide
"""
import argparse
import csv
import pathlib
import sys
import time

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent / "src"))
from bloodlog.baseline import baseline_plan, threshold_plan  # noqa: E402
from bloodlog.data import make_instance  # noqa: E402
from bloodlog.milp import solve_milp  # noqa: E402
from bloodlog.rolling import solve_rolling  # noqa: E402
from bloodlog.verifier import evaluate  # noqa: E402

METRICS = ("ok", "shortage", "waste", "substitutions", "collectes", "end_shortfall", "objective")
OUT = pathlib.Path(__file__).resolve().parent / "results"


def writer(path, fields):
    OUT.mkdir(exist_ok=True)
    f = open(path, "w", newline="", encoding="utf-8")
    w = csv.DictWriter(f, fieldnames=fields); w.writeheader()
    return f, w


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--quick", action="store_true")
    ap.add_argument("--only-weights", action="store_true", help="relancer seulement la sensibilite aux poids")
    a = ap.parse_args()
    seeds = 1 if a.quick else 3
    horizon = 21 if a.quick else 56
    variabilities = (0.2,) if a.quick else (0.0, 0.2, 0.4, 0.6)
    tl_oracle, tl_roll = (10, 5) if a.quick else (45, 15)

    f, w = writer(OUT / "results.csv", ["L", "variability", "seed", "method", "runtime_s", *METRICS]) if not a.only_weights else (open(__import__("os").devnull, "w"), None)
    for L in (() if a.only_weights else (42, 7)):
        for var in variabilities:
            for seed in range(seeds):
                inst = make_instance(seed=seed, T=horizon, L=L, variability=var)
                runs = {}
                t0 = time.time(); runs["baseline_fifo"] = (baseline_plan(inst), time.time() - t0)
                t0 = time.time(); runs["baseline_seuil"] = (threshold_plan(inst), time.time() - t0)
                t0 = time.time(); p = solve_rolling(inst, time_limit=tl_roll); runs["milp_replanifie"] = (p, time.time() - t0)
                t0 = time.time(); r = solve_milp(inst, time_limit=tl_oracle); runs["milp_oracle"] = (r["plan"], time.time() - t0)
                for name, (plan, rt) in runs.items():
                    res = evaluate(inst, plan)
                    w.writerow({"L": L, "variability": var, "seed": seed, "method": name, "runtime_s": round(rt, 1),
                                **{k: res[k] for k in METRICS}})
                f.flush()
                print(f"L={L} var={var} seed={seed} ok", flush=True)
    f.close()

    # Sensibilite aux poids de l'objectif (L=7, variabilite 0.2) : les politiques sont evaluees avec CHAQUE jeu de poids
    f, w = writer(OUT / "sensibilite_poids.csv", ["waste_w", "subst_w", "seed", "method", *METRICS])
    for waste_w in ((10,) if a.quick else (1, 10, 50)):
        for subst_w in ((1,) if a.quick else (0, 1, 10)):
            for seed in range(1 if a.quick else 2):
                weights = {"waste": waste_w, "substitution": subst_w}
                inst = make_instance(seed=seed, T=horizon, L=7, variability=0.2)
                r = solve_milp(inst, weights=weights, time_limit=tl_oracle)
                for name, plan in (("baseline_fifo", baseline_plan(inst)), ("baseline_seuil", threshold_plan(inst)),
                                   ("milp_oracle", r["plan"])):
                    res = evaluate(inst, plan, weights=weights)
                    w.writerow({"waste_w": waste_w, "subst_w": subst_w, "seed": seed, "method": name,
                                **{k: res[k] for k in METRICS}})
                f.flush()
                print(f"poids waste={waste_w} subst={subst_w} seed={seed} ok", flush=True)
    f.close()
    print("TERMINE")


if __name__ == "__main__":
    main()
