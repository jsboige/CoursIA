"""Compare baseline (collectes regulieres + FIFO) et MILP. Ecrit results/results.csv.

Usage : python run_experiments.py --seeds 3 --lives 42 7 --variability 0.2 0.4 --time-limit 60
"""
import argparse
import pathlib
import sys

import pandas as pd

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent / "src"))
from bloodlog.baseline import baseline_plan  # noqa: E402
from bloodlog.data import make_instance  # noqa: E402
from bloodlog.milp import solve_milp  # noqa: E402
from bloodlog.verifier import evaluate  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", type=int, default=3)
    ap.add_argument("--lives", type=int, nargs="+", default=[42, 7])
    ap.add_argument("--variability", type=float, nargs="+", default=[0.2, 0.4])
    ap.add_argument("--cover", type=float, default=1.05)
    ap.add_argument("--horizon", type=int, default=84)
    ap.add_argument("--time-limit", type=float, default=60)
    a = ap.parse_args()

    rows = []
    for L in a.lives:
        for var in a.variability:
            for seed in range(a.seeds):
                inst = make_instance(seed=seed, T=a.horizon, L=L, variability=var, cover=a.cover)
                base = evaluate(inst, baseline_plan(inst))
                r = solve_milp(inst, time_limit=a.time_limit)
                mil = evaluate(inst, r["plan"])
                for name, res in (("baseline_fifo", base), ("milp", mil)):
                    rows.append({"L": L, "variability": var, "seed": seed, "method": name,
                                 **{k: res[k] for k in ("ok", "shortage", "waste", "substitutions",
                                                        "collectes", "end_shortfall", "objective")}})
                print(f"L={L} var={var} seed={seed} -> baseline {base['objective']:.0f} | milp {mil['objective']:.0f}",
                      flush=True)
    df = pd.DataFrame(rows)
    out = pathlib.Path(__file__).resolve().parent / "results"
    out.mkdir(exist_ok=True)
    df.to_csv(out / "results.csv", index=False)
    print(df.groupby(["L", "variability", "method"])[["shortage", "waste", "substitutions", "objective"]]
          .mean().round(1).to_string())


if __name__ == "__main__":
    main()
