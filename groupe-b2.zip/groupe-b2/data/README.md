# Données : provenance, licence, reproductibilité

Toutes les données utilisées par le code sont **synthétiques** : aucune donnée de patient ou de donneur.
Elles sont générées par `src/bloodlog/data.py` avec une graine fixée (`make_instance(seed=...)`), donc
reproductibles à l'identique. Aucun jeu de données n'est téléchargé ni commité.

## Paramètres issus de sources publiques

| Paramètre | Valeur | Source |
|---|---|---|
| Part des groupes sanguins en France | A+ 38 %, O+ 36 %, B+ 8 %, A- 7 %, O- 6 %, AB+ 3 %, B- 1 %, AB- 1 % | Répartition attribuée à l'EFS, reprise par le site lonasante.com (page « Tableau de groupe sanguin : compatibilité donneur receveur », mise à jour avril 2026) et par neozone.org. Source secondaire : à rapprocher d'une publication EFS si disponible. |
| Durée de conservation des globules rouges | 42 jours | EFS (Guide du donneur 2025, `dondesang.efs.sante.fr`) ; fiche « caractéristiques des produits sanguins labiles » (La Revue du Praticien) |
| Durée de conservation des plaquettes | 7 jours | Mêmes sources EFS. Des sources non françaises ou grand public indiquent 5 jours (ex. Manuel MSD) : le modèle suit la valeur EFS de 7 jours. |
| Ordre de grandeur des besoins | environ 10 000 dons par jour en France | Communiqué de presse EFS (`presse.efs.sante.fr`) |
| Compatibilité ABO/Rh des globules rouges | Règle standard donneur → receveur (27 paires sur 8 groupes) | EFS et sources médicales ; vérifiée par des tests unitaires (`tests/test_bloodlog.py`) |
| Délai entre deux dons de sang | 8 semaines | EFS (Guide du donneur 2025). **Non modélisé** : voir les limites. |

## Hypothèses de modélisation (non issues de données)

- **Mise à l'échelle** : la demande moyenne simulée est de 100 unités par jour (`mean_daily`), soit environ 1 % de l'ordre de
  grandeur national. Le choix est une simplification pour garder des modèles résolubles en quelques secondes.
- **Demande** : tirage de Poisson par groupe, de moyenne proportionnelle à la part du groupe, modulée par un niveau journalier
  aléatoire d'écart-type relatif `variability`.
- **Collectes** : la capacité par groupe un jour de collecte est proportionnelle à la part du groupe (on ne choisit pas le groupe
  des donneurs). Taille d'une collecte : 300 unités environ ; budget de jours de collecte calibré sur la demande totale.
- **Stock initial** : 3 jours de demande, âges tirés uniformément ; la même quantité est exigée comme stock cible en fin
  d'horizon (pénalité douce).

Licence du code et des données générées : au choix du groupe (à indiquer dans le README principal).
