# Donnees

Toutes les donnees sont **synthetiques** (aucune donnee patient) et generees par
`src/bloodlog/data.py` avec une graine fixee (reproductible).

## A completer avant la remise (provenance et licence)
- Repartition des groupes sanguins (`SHARE`) : valeurs approximatives pour la France,
  **a verifier et citer** (source EFS / publication officielle, licence).
- Duree de vie : globules rouges 42 jours ; plaquettes 7 jours dans le catalogue du cours,
  mais certaines sources grand public indiquent 5 jours -> **trancher et citer la source**.
- Niveau et variabilite de la demande : hypotheses de modelisation (parametres `mean_daily`,
  `variability`), a justifier.

Aucun jeu telecharge n'est commite : si vous ajoutez des donnees publiques, ajoutez ici
le script de telechargement, la source et la licence.
