"""Verificateur INDEPENDANT du solveur : rejoue un plan jour par jour.

Il recompte les contraintes violees et les metriques sans utiliser le modele.
"""
from __future__ import annotations

from collections import defaultdict

from .data import DEFAULT_WEIGHTS, GROUPS, Instance, compatible


def evaluate(inst: Instance, plan: dict, weights: dict | None = None) -> dict:
    w = {**DEFAULT_WEIGHTS, **(weights or {})}
    T, L = inst.T, inst.L
    collect, issue = plan["collect"], plan["issue"]
    viol: list[str] = []
    by_t = defaultdict(list)
    for (d, r, a, t), n in issue.items():
        if not (0 <= t < T):
            viol.append(f"jour hors horizon: {(d, r, a, t)}")
            continue
        by_t[t].append((d, r, a, n))

    shortage = waste = subs = units_collected = 0
    collect_days = set()
    stock = None
    for t in range(T):
        if t == 0:
            avail = {g: [inst.init_stock.get((g, a), 0) for a in range(L)] for g in GROUPS}
        else:
            avail = {g: [0] + stock[g][:L - 1] for g in GROUPS}
        for g in GROUPS:
            n = collect.get((g, t), 0)
            if n < 0 or n > inst.cap[g]:
                viol.append(f"collecte invalide {g} jour {t}: {n} (cap {inst.cap[g]})")
            if n > 0:
                collect_days.add(t)
                units_collected += n
                avail[g][0] += n
        served = {g: 0 for g in GROUPS}
        for d, r, a, n in by_t[t]:
            if n < 0 or int(n) != n:
                viol.append(f"quantite invalide {(d, r, a, t)}: {n}")
                continue
            if not compatible(d, r):
                viol.append(f"incompatibilite {d}->{r} jour {t}")
            if not (0 <= a < L):
                viol.append(f"age invalide {a} jour {t}")
                continue
            avail[d][a] -= n
            if avail[d][a] < 0:
                viol.append(f"stock insuffisant {d} age {a} jour {t}")
                avail[d][a] = 0
            served[r] += n
            if d != r:
                subs += n
        for r in GROUPS:
            D = inst.demand[(r, t)]
            if served[r] > D:
                viol.append(f"sur-livraison {r} jour {t}: {served[r]} > {D}")
            shortage += max(0, D - served[r])
        for g in GROUPS:
            waste += avail[g][L - 1]               # perime a la fin du jour
        stock = avail
    if len(collect_days) > inst.N:
        viol.append(f"trop de jours de collecte: {len(collect_days)} > {inst.N}")

    final_stock = sum(sum(v[:L - 1]) for v in stock.values())   # unites non perimees en fin d'horizon
    end_shortfall = max(0, inst.safety_stock - final_stock)
    total_demand = sum(inst.demand.values())
    objective = (w["shortage"] * shortage + w["waste"] * waste + w["substitution"] * subs
                 + w["end_stock"] * end_shortfall)
    return {
        "ok": not viol, "violations": viol,
        "shortage": shortage, "waste": waste, "substitutions": subs,
        "collectes": len(collect_days), "units_collected": units_collected,
        "final_stock": final_stock, "end_shortfall": end_shortfall,
        "total_demand": total_demand,
        "service_rate": 1 - shortage / total_demand if total_demand else 1.0,
        "objective": objective,
    }
