"""Donnees synthetiques, compatibilites ABO/Rh et instance du probleme.

Parts des groupes sanguins en France (sources dans data/README.md).
"""
from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np

GROUPS = ["O-", "O+", "A-", "A+", "B-", "B+", "AB-", "AB+"]

SHARE = {"O-": 0.06, "O+": 0.36, "A-": 0.07, "A+": 0.38,
         "B-": 0.01, "B+": 0.08, "AB-": 0.01, "AB+": 0.03}   # source : voir data/README.md

# Poids de l'objectif (a justifier et a faire varier dans l'analyse de sensibilite)
DEFAULT_WEIGHTS = {"shortage": 100.0, "waste": 10.0, "substitution": 1.0, "end_stock": 50.0}


def compatible(donor: str, recipient: str) -> bool:
    """Compatibilite des globules rouges (donneur -> receveur)."""
    d_abo, d_rh = donor[:-1], donor[-1]
    r_abo, r_rh = recipient[:-1], recipient[-1]
    rh_ok = d_rh == "-" or r_rh == "+"
    abo_ok = d_abo == "O" or d_abo == r_abo or r_abo == "AB"
    return rh_ok and abo_ok


RECIPIENTS = {d: [r for r in GROUPS if compatible(d, r)] for d in GROUPS}
DONORS = {r: [d for d in GROUPS if compatible(d, r)] for r in GROUPS}


@dataclass
class Instance:
    T: int                      # horizon (jours)
    L: int                      # duree de vie (jours) : 42 globules rouges
    demand: dict                # (groupe, t) -> unites demandees
    init_stock: dict            # (groupe, age) -> unites disponibles a t=0
    cap: dict                   # groupe -> unites max collectees un jour de collecte
    N: int                      # nombre max de jours de collecte
    safety_stock: int = 0       # stock cible en fin d'horizon (penalite douce, meme pour toutes les methodes)
    seed: int = 0
    mean_daily: float = 0.0     # demande moyenne/jour (prevision utilisable par les politiques sans oracle)


def make_instance(seed: int = 0, T: int = 84, L: int = 42, mean_daily: float = 100,
                  variability: float = 0.2, collecte_size: int = 300,
                  cover: float = 1.02, init_days: float = 3) -> Instance:
    """Instance synthetique reproductible (graine fixee).

    variability : ecart-type relatif du niveau de demande journalier.
    cover       : budget de collectes ~ cover x demande totale / taille d'une collecte.
    """
    rng = np.random.default_rng(seed)
    demand = {}
    for t in range(T):
        level = max(0.1, 1.0 + variability * rng.standard_normal())
        for g in GROUPS:
            demand[(g, t)] = int(rng.poisson(mean_daily * SHARE[g] * level))
    init_stock = {}
    total0 = init_days * mean_daily
    for g in GROUPS:
        n_g = int(round(total0 * SHARE[g]))
        counts = rng.multinomial(n_g, [1.0 / L] * L)
        for a in range(L):
            if counts[a]:
                init_stock[(g, a)] = int(counts[a])
    cap = {g: math.ceil(collecte_size * SHARE[g]) for g in GROUPS}
    N = min(T, math.ceil(cover * T * mean_daily / collecte_size))
    return Instance(T=T, L=L, demand=demand, init_stock=init_stock, cap=cap, N=N,
                    safety_stock=int(round(total0)), seed=seed, mean_daily=mean_daily)
