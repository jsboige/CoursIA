"""Politique SANS oracle : re-planification periodique des collectes par MILP + distribution gloutonne.

Tous les `replan_every` jours :
  - on resout le MILP sur tout l'horizon restant, avec le stock reel observe et une PREVISION
    (demande moyenne) ; on n'en retient que les jours de collecte des `replan_every` prochains jours ;
Chaque jour :
  - la demande REELLE du jour est servie par une regle gloutonne : FIFO dans le groupe, puis
    substitution depuis un groupe compatible (en evitant O-, unites les plus anciennes d'abord).
La demande future reelle n'est jamais vue : c'est la difference avec le MILP "oracle".
"""
from __future__ import annotations

from .data import DONORS, GROUPS, SHARE, Instance
from .milp import solve_milp


def _dispatch(avail, demand_today, L):
    """Distribue le stock du jour. Retourne {(d, r, a): n}."""
    issue = {}
    short = {}
    for r in GROUPS:                                              # 1) meme groupe, FIFO
        need = demand_today[r]
        for a in range(L - 1, -1, -1):
            take = min(avail[r][a], need)
            if take > 0:
                issue[(r, r, a)] = issue.get((r, r, a), 0) + take
                avail[r][a] -= take
                need -= take
        if need > 0:
            short[r] = need
    for r, need in sorted(short.items(), key=lambda kv: SHARE[kv[0]]):   # 2) substitution, groupes rares d'abord
        cands = sorted(((d, a) for d in DONORS[r] if d != r for a in range(L) if avail[d][a] > 0),
                       key=lambda da: (da[0] == "O-", -da[1]))
        for d, a in cands:
            take = min(avail[d][a], need)
            issue[(d, r, a)] = issue.get((d, r, a), 0) + take
            avail[d][a] -= take
            need -= take
            if need == 0:
                break
    return issue


def solve_rolling(inst: Instance, replan_every: int = 7, weights=None, time_limit: float = 20,
                  mip_gap: float = 0.02) -> dict:
    T, L = inst.T, inst.L
    collect, issue = {}, {}
    stock, used, fallbacks = None, 0, 0
    planned_days: dict[int, dict] = {}
    for t in range(T):
        if t == 0:
            avail = {g: [inst.init_stock.get((g, a), 0) for a in range(L)] for g in GROUPS}
        else:
            avail = {g: [0] + stock[g][:L - 1] for g in GROUPS}
        if t % replan_every == 0:
            h = T - t
            forecast = {(g, k): int(round(inst.mean_daily * SHARE[g])) for g in GROUPS for k in range(h)}
            sub = Instance(T=h, L=L, demand=forecast,
                           init_stock={(g, a): v for g in GROUPS for a, v in enumerate(avail[g]) if v},
                           cap=inst.cap, N=inst.N - used, safety_stock=inst.safety_stock,
                           mean_daily=inst.mean_daily)
            res = solve_milp(sub, weights=weights, time_limit=time_limit, mip_gap=mip_gap)
            planned_days = {}
            if res["plan"] is None:
                fallbacks += 1
            else:
                for (g, k), n in res["plan"]["collect"].items():
                    if k < replan_every:
                        planned_days.setdefault(t + k, {})[g] = n
        if t in planned_days and used < inst.N:
            used += 1
            for g, n in planned_days[t].items():
                collect[(g, t)] = n
                avail[g][0] += n
        day = _dispatch(avail, {g: inst.demand[(g, t)] for g in GROUPS}, L)
        for (d, r, a), n in day.items():
            issue[(d, r, a, t)] = n
        stock = avail
    return {"collect": collect, "issue": issue, "fallbacks": fallbacks}
