"""Modele MILP multi-periodes (stock par groupe x age, substitutions ABO/Rh).

Resolu avec scipy.optimize.milp (HiGHS). Meme logique que PuLP/CBC vu dans
Search-09-LinearProgramming : variables, objectif, contraintes, solve, lecture.

Hypothese MVP : demande CONNUE sur l'horizon (borne optimiste). Extension :
horizon glissant / scenarios.
"""
from __future__ import annotations

import numpy as np
from scipy.optimize import Bounds, LinearConstraint, milp
from scipy.sparse import coo_matrix

from .data import DEFAULT_WEIGHTS, DONORS, GROUPS, RECIPIENTS, Instance


def solve_milp(inst: Instance, weights: dict | None = None,
               time_limit: float = 120, mip_gap: float = 0.01) -> dict:
    w = {**DEFAULT_WEIGHTS, **(weights or {})}
    T, L = inst.T, inst.L
    idx: dict = {}
    cost, lb, ub = [], [], []

    def add(key, c, lo, hi):
        idx[key] = len(cost)
        cost.append(c); lb.append(lo); ub.append(hi)

    add(("endshort",), w["end_stock"], 0, inst.safety_stock)   # manque de stock final
    for t in range(T):
        add(("z", t), 0.0, 0, 1)                                  # jour de collecte
        for g in GROUPS:
            add(("c", g, t), 0.0, 0, inst.cap[g])                 # unites collectees
            add(("short", g, t), w["shortage"], 0, inst.demand[(g, t)])
            for a in range(L):
                add(("s", g, a, t), w["waste"] if a == L - 1 else 0.0, 0, np.inf)
                for r in RECIPIENTS[g]:
                    add(("u", g, r, a, t), w["substitution"] if r != g else 0.0, 0, np.inf)

    rows, cols, vals, lo, hi = [], [], [], [], []

    def con(terms, l, h):
        i = len(lo)
        for k, v in terms:
            rows.append(i); cols.append(idx[k]); vals.append(v)
        lo.append(l); hi.append(h)

    # 1) Conservation du stock : s[g,a,t] + sorties = disponible (vieillissement)
    for t in range(T):
        for g in GROUPS:
            for a in range(L):
                terms = [(("s", g, a, t), 1)] + [(("u", g, r, a, t), 1) for r in RECIPIENTS[g]]
                rhs = 0
                if a == 0:
                    terms.append((("c", g, t), -1))
                elif t > 0:
                    terms.append((("s", g, a - 1, t - 1), -1))
                if t == 0:
                    rhs = inst.init_stock.get((g, a), 0)
                con(terms, rhs, rhs)
    # 2) Demande : livre + penurie = demande
    for t in range(T):
        for r in GROUPS:
            terms = [(("u", d, r, a, t), 1) for d in DONORS[r] for a in range(L)]
            terms.append((("short", r, t), 1))
            D = inst.demand[(r, t)]
            con(terms, D, D)
    # 3) Collectes : capacite par groupe liee au jour de collecte, budget de jours
    for t in range(T):
        for g in GROUPS:
            con([(("c", g, t), 1), (("z", t), -inst.cap[g])], -np.inf, 0)
    con([(("z", t), 1) for t in range(T)], -np.inf, inst.N)

    # 4) Stock cible en fin d'horizon, penalite douce (evite l'effet de bord 'stock vide')
    con([(('s', g, a, T - 1), 1) for g in GROUPS for a in range(L - 1)] + [(('endshort',), 1)],
        inst.safety_stock, np.inf)

    n = len(cost)
    A = coo_matrix((vals, (rows, cols)), shape=(len(lo), n)).tocsr()
    integrality = np.ones(n)
    res = milp(c=np.array(cost), constraints=LinearConstraint(A, lo, hi),
               integrality=integrality, bounds=Bounds(lb, ub),
               options={"time_limit": time_limit, "mip_rel_gap": mip_gap})
    if res.x is None:
        return {"status": res.message, "plan": None, "objective": None}

    x = res.x
    collect, issue = {}, {}
    for key, i in idx.items():
        v = int(round(x[i]))
        if v <= 0:
            continue
        if key[0] == "c":
            collect[(key[1], key[2])] = v
        elif key[0] == "u":
            issue[(key[1], key[2], key[3], key[4])] = v
    return {"status": res.message, "solver_status": res.status,
            "objective": float(res.fun), "mip_gap": getattr(res, "mip_gap", None),
            "plan": {"collect": collect, "issue": issue}}
