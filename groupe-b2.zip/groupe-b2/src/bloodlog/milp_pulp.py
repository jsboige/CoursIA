"""Meme modele MILP ecrit avec PuLP (CBC), comme dans Search-09-LinearProgramming.

Necessite `pip install pulp`. Meme signature et meme format de retour que milp.solve_milp,
ce qui permet de comparer les deux implementations (voir tests/test_pulp.py).
"""
from __future__ import annotations

from .data import DEFAULT_WEIGHTS, DONORS, GROUPS, RECIPIENTS, Instance


def solve_milp_pulp(inst: Instance, weights: dict | None = None,
                    time_limit: float = 120, mip_gap: float = 0.01) -> dict:
    import pulp

    w = {**DEFAULT_WEIGHTS, **(weights or {})}
    T, L = inst.T, inst.L
    gi = {g: i for i, g in enumerate(GROUPS)}                 # noms PuLP sans '+'/'-' (evite les collisions)
    prob = pulp.LpProblem("blood_logistics", pulp.LpMinimize)

    z = {t: pulp.LpVariable(f"z_{t}", cat="Binary") for t in range(T)}
    c = {(g, t): pulp.LpVariable(f"c_{gi[g]}_{t}", 0, inst.cap[g], cat="Integer") for g in GROUPS for t in range(T)}
    short = {(g, t): pulp.LpVariable(f"sh_{gi[g]}_{t}", 0, inst.demand[(g, t)], cat="Integer")
             for g in GROUPS for t in range(T)}
    s = {(g, a, t): pulp.LpVariable(f"s_{gi[g]}_{a}_{t}", 0, cat="Integer")
         for g in GROUPS for a in range(L) for t in range(T)}
    u = {(d, r, a, t): pulp.LpVariable(f"u_{gi[d]}_{gi[r]}_{a}_{t}", 0, cat="Integer")
         for d in GROUPS for r in RECIPIENTS[d] for a in range(L) for t in range(T)}
    endshort = pulp.LpVariable("endshort", 0, inst.safety_stock, cat="Integer")

    prob += (w["shortage"] * pulp.lpSum(short.values())
             + w["waste"] * pulp.lpSum(s[(g, L - 1, t)] for g in GROUPS for t in range(T))
             + w["substitution"] * pulp.lpSum(v for (d, r, a, t), v in u.items() if d != r)
             + w["end_stock"] * endshort), "Objectif"

    for t in range(T):
        for g in GROUPS:
            for a in range(L):
                out = pulp.lpSum(u[(g, r, a, t)] for r in RECIPIENTS[g])
                if a == 0:
                    inflow = c[(g, t)]
                elif t > 0:
                    inflow = s[(g, a - 1, t - 1)]
                else:
                    inflow = 0
                rhs = inst.init_stock.get((g, a), 0) if t == 0 else 0
                prob += s[(g, a, t)] + out == inflow + rhs, f"flow_{gi[g]}_{a}_{t}"
        for r in GROUPS:
            prob += (pulp.lpSum(u[(d, r, a, t)] for d in DONORS[r] for a in range(L)) + short[(r, t)]
                     == inst.demand[(r, t)]), f"demand_{gi[r]}_{t}"
        for g in GROUPS:
            prob += c[(g, t)] <= inst.cap[g] * z[t], f"cap_{gi[g]}_{t}"
    prob += pulp.lpSum(z.values()) <= inst.N, "budget_collectes"
    prob += (pulp.lpSum(s[(g, a, T - 1)] for g in GROUPS for a in range(L - 1)) + endshort
             >= inst.safety_stock), "stock_final"

    prob.solve(pulp.PULP_CBC_CMD(msg=False, timeLimit=time_limit, gapRel=mip_gap))
    status = pulp.LpStatus[prob.status]
    if status not in ("Optimal", "Not Solved") or any(v.value() is None for v in c.values()):
        return {"status": status, "plan": None, "objective": None}
    collect = {k: int(round(v.value())) for k, v in c.items() if round(v.value() or 0) > 0}
    issue = {k: int(round(v.value())) for k, v in u.items() if round(v.value() or 0) > 0}
    return {"status": status, "objective": float(pulp.value(prob.objective)), "mip_gap": None,
            "plan": {"collect": collect, "issue": issue}}
