"""Baseline : collectes regulieres + FIFO (plus ancien d'abord), sans substitution."""
from __future__ import annotations

from .data import GROUPS, Instance


def baseline_plan(inst: Instance) -> dict:
    T, L = inst.T, inst.L
    days = sorted({int(i * T / inst.N) for i in range(inst.N)})
    collect, issue = {}, {}
    stock = None
    for t in range(T):
        if t == 0:
            avail = {g: [inst.init_stock.get((g, a), 0) for a in range(L)] for g in GROUPS}
        else:
            avail = {g: [0] + stock[g][:L - 1] for g in GROUPS}  # vieillissement, le dernier age perime
        if t in days:
            for g in GROUPS:
                collect[(g, t)] = inst.cap[g]
                avail[g][0] += inst.cap[g]
        for r in GROUPS:
            need = inst.demand[(r, t)]
            for a in range(L - 1, -1, -1):         # FIFO : plus ancien d'abord
                take = min(avail[r][a], need)
                if take > 0:
                    issue[(r, r, a, t)] = take
                    avail[r][a] -= take
                    need -= take
        stock = avail
    return {"collect": collect, "issue": issue}
