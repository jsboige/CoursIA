"""Baselines SANS substitution, servant de comparaison.

- baseline_plan      : collectes regulieres (calendrier fixe) + FIFO. C'est la baseline du sujet.
- threshold_plan     : baseline renforcee : collecte quand le stock utilisable passe sous un seuil
                       (politique de point de commande), FIFO, sans substitution.
"""
from __future__ import annotations

from .data import GROUPS, Instance


def _simulate(inst: Instance, collect_rule) -> dict:
    """Boucle commune : vieillissement, collecte (selon collect_rule), FIFO par groupe."""
    T, L = inst.T, inst.L
    collect, issue = {}, {}
    stock, used = None, 0
    for t in range(T):
        if t == 0:
            avail = {g: [inst.init_stock.get((g, a), 0) for a in range(L)] for g in GROUPS}
        else:
            avail = {g: [0] + stock[g][:L - 1] for g in GROUPS}      # le dernier age perime
        if used < inst.N and collect_rule(inst, t, avail, used):
            used += 1
            for g in GROUPS:
                collect[(g, t)] = inst.cap[g]
                avail[g][0] += inst.cap[g]
        for r in GROUPS:
            need = inst.demand[(r, t)]
            for a in range(L - 1, -1, -1):                            # FIFO : plus ancien d'abord
                take = min(avail[r][a], need)
                if take > 0:
                    issue[(r, r, a, t)] = take
                    avail[r][a] -= take
                    need -= take
        stock = avail
    return {"collect": collect, "issue": issue}


def baseline_plan(inst: Instance) -> dict:
    """Collectes a intervalles reguliers (N jours repartis sur l'horizon) + FIFO."""
    days = {int(i * inst.T / inst.N) for i in range(inst.N)}
    return _simulate(inst, lambda inst, t, avail, used: t in days)


def threshold_plan(inst: Instance, reorder_days: float = 3.0) -> dict:
    """Collecte quand le stock utilisable (ages < L-1 apres vieillissement) < reorder_days x demande moyenne."""
    level = reorder_days * inst.mean_daily
    def rule(inst, t, avail, used):
        usable = sum(sum(v[:inst.L - 1]) for v in avail.values())
        return usable < level
    return _simulate(inst, rule)
