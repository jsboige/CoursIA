"""B2 - Logistique du don du sang : collectes et peremption."""
