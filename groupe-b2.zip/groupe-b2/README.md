# Groupe B2 - Logistique du don du sang : collectes et peremption

> Squelette de depart (MVP technique). A completer : membres, resultats, limites, references.

## Membres
- @pseudo1, @pseudo2, @pseudo3  *(pseudos GitHub uniquement)*

## Problematique
Planifier les jours de collecte et les delivrances (avec substitutions ABO/Rh) pour minimiser
penuries, peremptions et substitutions, sous contrainte de duree de vie des produits.

## Architecture
- `src/bloodlog/data.py` : groupes, compatibilites, instance synthetique reproductible.
- `src/bloodlog/baseline.py` : collectes regulieres + FIFO sans substitution.
- `src/bloodlog/milp.py` : MILP multi-periodes (stock groupe x age), `scipy.optimize.milp` (HiGHS).
- `src/bloodlog/verifier.py` : **verificateur independant** (rejoue le plan, recompte les violations).
- `run_experiments.py` : baseline vs MILP, ecrit `results/results.csv`.
- `notebooks/B2-resultats.ipynb` : demarche, comparaison baseline vs MILP, sensibilite a la variabilite, limites
  (lancer depuis `notebooks/` ; `FAST = False` pour les resultats finaux).
- `tests/` : tests unitaires.
- `slides/` : support de soutenance (a ajouter).

## Installation et execution
```bash
pip install -r requirements.txt
python -m unittest discover -s tests -v
python run_experiments.py --seeds 3 --lives 42 7 --variability 0.2 0.4 --time-limit 60
```

## Modele (resume)
- Stock `s[g,a,t]` par groupe `g`, age `a` (0..L-1), jour `t` ; vieillissement d'un jour a l'autre.
- Delivrance `u[d,r,a,t]` du groupe donneur `d` au receveur `r` si compatible ; penurie = demande - livre.
- Perime = unites d'age L-1 non delivrees en fin de journee.
- Collecte : binaire par jour, capacite par groupe, budget de N jours.
- Objectif : 100 x penurie + 10 x peremption + 1 x substitution + 50 x manque de stock final.

## Resultats / Limites / Repartition / Licences / References
*(a completer apres les experiences)*
Points a documenter honnetement : demande connue sur l'horizon (borne optimiste), baseline simple
(a renforcer), poids de l'objectif arbitraires (analyse de sensibilite), parts de groupes a sourcer.
Reference du catalogue : Osorio, Brailsford & Smith (2015), Int. J. Prod. Res.
